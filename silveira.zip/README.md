# Site Institucional Silveira Advogados

Projeto - Silveira Advogados
Versão - 1.1 - 28-11-2023

 ***

 ### Linguagens Ultilizadas

 Html5<br>
 CSS3 <br>
 Javascript<br>
 PHP<br>


### Frameworks e Bibliotecas

Codeigniter4<br>
Bootstrap<br>
IcoFont<br>
Google fonts<br>


<details>
<summary>Introdução</summary>
<br>
<br><br>
<pre>
Silveira advogados é um projeto para portfólio de site institucional para advogados responsivo e dinâmico.  
</pre>
</details>

---

<details>
<summary>Log de Alterações</summary>
<br>
<br><br>
<pre>
Log 1.1 
- Implementado framework codeigniter 4
</pre>
</details>


